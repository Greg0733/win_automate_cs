from ._window_ocr import *
