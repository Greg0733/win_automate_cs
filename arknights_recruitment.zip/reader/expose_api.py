import json
import sys
from contextlib import redirect_stdout
from io import StringIO

import easyocr
from PIL import ImageDraw
from flask import Flask

import window_ocr

IMAGE_MODE = "RGB"
FLASK_STARTED_STDOUT_LINE = "* Serving Flask app"


def drawn_text_size(drawer: ImageDraw.ImageDraw, text_str: str):
    return [round(x) for x in drawer.textbbox((0, 0), text_str)[2:4]]


def print_available_fonts(font_name_contains: str = ""):
    from matplotlib import font_manager

    print(f"List of all fonts containing {font_name_contains} found through default paths in the system: ")
    for font in font_manager.findSystemFonts(fontpaths=None, fontext='ttf'):
        if font_name_contains in font.lower():
            print(font)


# Press the green button in the gutter to run the script.
def start_reader(on_ready_pipe=None, on_exit=None):
    with open("../config_arknights_recruitment.json", "r", encoding="utf-8") as config_file:
        config = json.load(config_file)

        crop_rectangles = {}
        for crop_data_name, crop_data_row in config["crop"].items():
            crop_rectangles[crop_data_name] = (float(crop_data_row["left"]),
                                               float(crop_data_row["top"]),
                                               float(crop_data_row["right"]),
                                               float(crop_data_row["bottom"]))

        ocr_language = config["ocr texts"]["language"]

        config_user_filename = config["preferences filename"]

    with open(f"../{config_user_filename}", "r", encoding="utf-8") as config_user_file:
        config_user = json.load(config_user_file)
        window_title_contains = config_user["window title contains"]
        default_local_port = config_user["local port"]

    easyocr_reader = easyocr.Reader([ocr_language])
    ocr = window_ocr.WindowOcr(easyocr_reader.readtext)
    ocr.search_window_handle(lambda window: window_title_contains in window[1])

    flask_app = Flask(__name__)

    @flask_app.route("/<req_line_name>")
    def screen(req_line_name):
        ocr_results = ocr.read_handle(crop_rectangles[req_line_name])

        # ocr.draw_results("")

        return window_ocr.simplify_results(ocr_results)

    @flask_app.route("/stop")
    def stop():
        if on_exit is None:
            return "on_exit not set, unable to quit"
        on_exit()
        return "exiting"

    class MyIO(StringIO):
        def __init__(self):
            super().__init__()
            self.to_call = on_ready_pipe is not None

        def write(self, arg):
            if self.to_call and FLASK_STARTED_STDOUT_LINE in arg:
                on_ready_pipe.send(0)
                self.to_call = False
            sys.__stdout__.write(arg)

    if on_ready_pipe is None:
        flask_app.run("localhost", default_local_port, False)
    else:
        with redirect_stdout(MyIO()):
            flask_app.run("localhost", default_local_port, False)


if __name__ == '__main__':
    start_reader()
