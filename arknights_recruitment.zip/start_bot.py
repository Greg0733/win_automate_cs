import os
import sys


import signal
import subprocess
from multiprocessing import Process, Pipe

from reader import expose_api


def on_exit(sig, func=None):
    p.terminate()


if __name__ == '__main__':
    # TODO run in background to eliminate the need for this
    # Does not work inside PyCharm but works externally
    signal.signal(signal.SIGINT, on_exit)

    read_pipe, write_pipe = Pipe(duplex=False)
    p = Process(target=expose_api.start_reader, args=[write_pipe])
    p.start()
    _ = read_pipe.recv()
    for clicker_path in sys.argv[1:]:
        subprocess.run(clicker_path)
    p.terminate()
