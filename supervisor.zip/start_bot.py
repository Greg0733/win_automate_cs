import signal
import subprocess
import sys
from multiprocessing import Process, Pipe

from reader import expose_api


def on_exit(sig, func=None):
    p.terminate()


if __name__ == '__main__':
    config_folder = sys.argv[1]
    # TODO run in background to eliminate the need for this
    signal.signal(signal.SIGINT, on_exit)

    read_pipe, write_pipe = Pipe(duplex=False)
    p = Process(target=expose_api.start_reader, args=[config_folder, write_pipe])
    p.start()
    _ = read_pipe.recv()
    for clicker_path in sys.argv[1:]:
        subprocess.run(f"{config_folder}/clicker.exe")
    p.terminate()
