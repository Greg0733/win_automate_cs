import subprocess
import sys
import json

from reader.api import ReaderApi


if __name__ == '__main__':
    config_folder = sys.argv[1]
    reader_api = ReaderApi(config_folder)

    p = subprocess.Popen(f"{config_folder}/clicker.exe",
                         stdin=subprocess.PIPE, encoding="UTF-8", bufsize=1,
                         stdout=subprocess.PIPE)  # bufsize=1 => line buffered

    line = p.stdout.readline()
    while len(line) > 0:
        p.stdin.write(json.dumps(reader_api.screen(line[:-1])) + "\n")
        line = p.stdout.readline()
