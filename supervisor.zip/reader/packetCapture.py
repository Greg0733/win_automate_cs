import libpcap
import ctypes as ct

if __name__ == "__main__":
    err_buf = ct.create_string_buffer(256)
    print(err_buf.value)
    print(libpcap.init(libpcap.PCAP_CHAR_ENC_UTF_8, err_buf))
    print(err_buf.value)

    devs_p_p = ct.pointer(ct.pointer(libpcap.pcap_if_t()))
    print(libpcap.findalldevs(devs_p_p, err_buf))

    cur_dev_p = devs_p_p.contents
    while cur_dev_p:
        cur_dev_struct = cur_dev_p.contents
        cur_address_p = cur_dev_struct.addresses
        print("name", cur_dev_struct.name, "description", cur_dev_struct.description, "address")
        while cur_address_p:
            cur_address_struct = cur_address_p.contents
            cur_ipv4_addr = cur_address_struct.addr.contents.ipv4_addr
            for ipv4_byte in cur_ipv4_addr:
                ipv4_int = ipv4_byte if ipv4_byte >= 0 else ipv4_byte + 256
                print(ipv4_int, end=" ")
            print()
            cur_address_p = cur_address_struct.next

        cur_dev_p = cur_dev_struct.next
