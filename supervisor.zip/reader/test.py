import win32api

import window_ocr
import dxgi
from reader.api import ReaderApi

if __name__ == "__main__":
    reader_api = ReaderApi("../arknights recruitment test")
    print(reader_api.copy_screen_text())
    # print(reader_api.copy_screen_text("arknights recruitment list"))

    # hwnd = window_ocr.get_window_handle("bloc-notes")
    # pos, size = window_ocr.screenshot_pos_size(hwnd, [0, 0, 1, 1])
    #
    # dxgiReader = dxgi.DXGICamera()
    #
    # monitors = win32api.EnumDisplayMonitors(None, None)
    # print(monitors)
    #
    # m_info = win32api.GetMonitorInfo(monitors[0][0])
    # print(m_info)

