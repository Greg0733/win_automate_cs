if __name__ == '__main__':
    """with open("../config.json", "r", encoding="utf-8") as config_file:
        config = json.load(config_file)

        config_user = config["user dependant"]
        window_title_contains = config_user["window title contains"]
        default_local_port = config_user["local port"]

        crop_rectangles = {}
        for crop_data_name, crop_data_row in config["crop"].items():
            crop_rectangles[crop_data_name] = (float(crop_data_row["left"]),
                                               float(crop_data_row["top"]),
                                               float(crop_data_row["right"]),
                                               float(crop_data_row["bottom"]))

        ocr_language = config["ocr texts"]["language"]

    easyocr_reader = easyocr.Reader([ocr_language])
    ocr = window_ocr.WindowOcr(easyocr_reader.readtext)
    ocr.search_window_handle(lambda window: window_title_contains in window[1])

    ocr.draw_read_handle("", crop_rectangles["arknights recruitment insufficient resource"])"""

    """
    35% faster with cached handle (however only around 4ms per call even without, not much)
    def to_time():
        screenshot_background(lambda window: "itézed" in window[1].lower(),
                              crop_rectangles["arknights recruitment list"],
                              "RGB")

    # print(timeit.timeit(to_time, number=1000))

    window_handle = window_ocr.get_screenshot_handle(lambda window: "itézed" in window[1].lower())

    def to_time3():
        screenshot_from_handle(window_handle, crop_rectangles["arknights recruitment list"], "RGB")

    print(timeit.timeit(to_time3, number=1000))
    """
