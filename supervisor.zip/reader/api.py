import json

import easyocr
from PIL import ImageDraw

from reader import window_ocr

IMAGE_MODE = "RGB"
FLASK_STARTED_STDOUT_LINE = "* Serving Flask app"


def drawn_text_size(drawer: ImageDraw.ImageDraw, text_str: str):
    return [round(x) for x in drawer.textbbox((0, 0), text_str)[2:4]]


def print_available_fonts(font_name_contains: str = ""):
    from matplotlib import font_manager

    print(f"List of all fonts containing {font_name_contains} found through default paths in the system: ")
    for font in font_manager.findSystemFonts(fontpaths=None, fontext='ttf'):
        if font_name_contains in font.lower():
            print(font)


class ReaderApi:
    def __init__(self, config_folder):
        with open(f"{config_folder}/config.json", "r", encoding="utf-8") as config_file:
            config = json.load(config_file)

            self.crop_rectangles = {}
            for crop_data_name, crop_data_row in config["crop"].items():
                self.crop_rectangles[crop_data_name] = (float(crop_data_row["left"]),
                                                        float(crop_data_row["top"]),
                                                        float(crop_data_row["right"]),
                                                        float(crop_data_row["bottom"]))

            ocr_language = config["ocr texts"]["language"]

            config_user_filename = config["preferences filename"]

        with open(f"{config_folder}/{config_user_filename}", "r", encoding="utf-8") as config_user_file:
            config_user = json.load(config_user_file)
            window_title_contains = config_user["window title contains"]

        easyocr_reader = easyocr.Reader([ocr_language])
        self.ocr = window_ocr.WindowOcr(easyocr_reader.readtext)
        self.ocr.search_window_handle(lambda window: window_title_contains.lower() in window[1].lower())

    def screen(self, req_line_name):
        ocr_results = self.ocr.read_handle(self.crop_rectangles[req_line_name])

        # ocr.draw_results("")

        return window_ocr.simplify_results(ocr_results)
