import json

import easyocr
from PIL import ImageDraw

from reader import window_ocr


def drawn_text_size(drawer: ImageDraw.ImageDraw, text_str: str):
    return [round(x) for x in drawer.textbbox((0, 0), text_str)[2:4]]


def print_available_fonts(font_name_contains: str = ""):
    from matplotlib import font_manager

    print(f"List of all fonts containing {font_name_contains} found through default paths in the system: ")
    for font in font_manager.findSystemFonts(fontpaths=None, fontext='ttf'):
        if font_name_contains in font.lower():
            print(font)


class ReaderApi:
    def __init__(self, config_folder):
        self.handle_configured = False
        self.adb_connected = False

        with open(f"{config_folder}/config.json", "r", encoding="utf-8") as config_file:
            config = json.load(config_file)

            # None is the default value, it will take a screenshot of the whole screen
            self.crop_rectangles = {None: [0, 0, 1, 1]}
            for crop_data_name, crop_data_row in config["crop"].items():
                self.crop_rectangles[crop_data_name] = (float(crop_data_row["left"]),
                                                        float(crop_data_row["top"]),
                                                        float(crop_data_row["right"]),
                                                        float(crop_data_row["bottom"]))

            ocr_language = config["ocr texts"]["language"]

            config_user_filename = config["preferences filename"]

        easyocr_reader = easyocr.Reader([ocr_language])
        self.ocr = window_ocr.WindowOcr(easyocr_reader.readtext)

        with open(f"{config_folder}/{config_user_filename}", "r", encoding="utf-8") as config_user_file:
            config_user = json.load(config_user_file)
            if "window title contains" in config_user:
                self.ocr.search_window_handle(config_user["window title contains"])
                self.handle_configured = True

            if "emulator IP" in config_user:
                self.ocr.connect_adb(f"{config_folder}/{config["adb path"]}", config_user["emulator IP"])
                self.adb_connected = True

    def read_screen(self, req_line_name=None):
        if self.handle_configured:
            return self._read_window(req_line_name)
        if self.adb_connected:
            return self._read_adb(req_line_name)

        raise RuntimeError("Can't read window : no method configured in preferences")

    def _read_window(self, req_line_name=None):
        ocr_results = self.ocr.read_handle(self.crop_rectangles[req_line_name])

        return window_ocr.simplify_results(ocr_results)

    def _read_adb(self, req_line_name=None):
        ocr_results = self.ocr.read_adb(self.crop_rectangles[req_line_name])

        return window_ocr.simplify_results(ocr_results)

    def copy_screen_text(self, req_line_name=None):
        ret = self.read_screen(req_line_name)
        self.ocr.draw_results("")

        return ret
