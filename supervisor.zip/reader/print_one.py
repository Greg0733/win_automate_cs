import easyocr

from reader import window_ocr

if __name__ == "__main__":
    language = "en"
    window = "itézed"
    crop_data = {
            "left": 0.160547,
            "top": 0.826868,
            "right": 0.935156,
            "bottom": 0.889368
        }

    easyocr_reader = easyocr.Reader([language])

    ocr = window_ocr.WindowOcr(easyocr_reader.readtext)
    ocr.search_window_handle(lambda w: window.lower() in w[1].lower())
    crop_rect = [crop_data["left"], crop_data["top"], crop_data["right"], crop_data["bottom"]]

    ocr_results = ocr.draw_read_handle("print_one_", crop_rect)
    simplified = window_ocr.simplify_results(ocr_results)

    print(f"Language: {language}")
    print(f"Window: {window}")
    print(f"Crop region: {crop_data}")
    print()
    print(f"Data: {ocr_results}")
    print()
    print(f"Simplified data: {simplified}")
