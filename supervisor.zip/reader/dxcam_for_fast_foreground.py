import dxcam
import pygetwindow as gw
import cv2
import numpy as np


def capture_window(win_title):
    # Récupérer la fenêtre par son titre
    window = gw.getWindowsWithTitle(win_title)
    if not window:
        raise ValueError(f"Aucune fenêtre trouvée avec le titre : {win_title}")

    win = window[0]  # On prend la première fenêtre trouvée
    bbox = (win.left, win.top, win.right, win.bottom)

    # Initialiser DXGI capture
    camera = dxcam.create()
    frame = camera.grab(region=bbox)  # Capture de la région spécifique

    if frame is None:
        raise RuntimeError("Échec de la capture")

    return frame  # L'image capturée sous forme de tableau NumPy


# Exemple d'utilisation

window_title = "Vid-tourelles"  # Remplace par le vrai titre
frame = capture_window(window_title)

if frame is not None:
    # Correction des couleurs (BGRA -> RGB)
    frame = cv2.cvtColor(np.array(frame), cv2.COLOR_BGRA2RGB)
    cv2.imshow("Capture", np.array(frame))
    cv2.waitKey(0)
    cv2.destroyAllWindows()
