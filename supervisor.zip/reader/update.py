import html
import json
import logging
import sys

import requests

RARITY_TO_TAG = {2: "starter",
                 5: "senior operator",
                 6: "top operator"}

RARITY_KEY = "rarity"
TITLE_KEY = "title"

OPERATORS_PSEUDONYMS = {
    "'justice knight'": ["\"justice knight\""],
    "THRM-EX".lower(): ["Thermal-EX".lower()],
    "".lower(): ["".lower()],
    "Rosa (Poca)".lower(): ["Роса".lower()],
    "Istina".lower(): ["Истина".lower()],
    "Gummy".lower(): ["Гум".lower()],
    "Zima".lower(): ["Зима".lower()]
}

TAGS_SYNONYMS = {
    "crowd-control": ["crowd control"]
}


def send_request(url, expected_response_name):
    response = requests.get(url)
    if response.status_code != 200:
        raise IOError(f"request for {expected_response_name} failed")

    try:
        response_json = response.json()
    except requests.exceptions.JSONDecodeError:
        raise IOError(f"{expected_response_name} is not json-formatted")

    return response_json


def add_in_dict_list(data_dict, key, value):
    if key not in data_dict:
        data_dict[key] = []

    data_dict[key].append(value)


def operator_data_from_json(json_rarity, json_title):
    return {RARITY_KEY: int(json_rarity), TITLE_KEY: html.unescape(json_title)}


def try_download_gamepress():
    arknights_json = send_request("https://gamepress.gg/json-list?_format=json&game_tid=1026&", "arknights data")

    try:
        operators_data_url = next(filter(lambda x: "operator-data-full" in x[TITLE_KEY], arknights_json))["url"]
    except (StopIteration, KeyError):
        raise IOError("Operator data url not found in arknights json")

    operators_json = send_request(operators_data_url, "operators data")

    operators_per_tag = {}
    for operator_json in operators_json:
        try:
            if "on" not in operator_json["in_crafting_pool"].lower():
                continue

            operator_data = operator_data_from_json(operator_json["rarity"], operator_json["title"])
            operator_rarity = operator_data[RARITY_KEY]
            if operator_rarity in RARITY_TO_TAG:
                add_in_dict_list(operators_per_tag, RARITY_TO_TAG[operator_rarity], operator_data)

            add_in_dict_list(operators_per_tag, operator_json["position"].lower(), operator_data)

            add_in_dict_list(operators_per_tag, operator_json["profession_plain"].lower(), operator_data)

            for tag in operator_json["tags"].split(", "):
                if not tag.startswith("tag-"):
                    raise IOError("tag element does not start with 'tag-'")

                add_in_dict_list(operators_per_tag, tag[4:].lower(), operator_data)

        except (KeyError, ValueError):
            raise IOError(f"{operator_json} is not properly formatted (missing key or value of unexpected type)")

    return operators_per_tag


def find_translation_aceship(cn_name, json_data, cn_key, en_key):
    for json_elem in json_data:
        if json_elem[cn_key] == cn_name:
            return json_elem[en_key].lower()


def try_download_aceship():
    operators_json = send_request("https://raw.githubusercontent.com/Aceship/AN-EN-Tags/master/json/tl-akhr.json",
                                  "operators data")
    tags_json = send_request("https://github.com/Aceship/AN-EN-Tags/raw/master/json/tl-tags.json",
                             "tags data")
    types_json = send_request("https://raw.githubusercontent.com/Aceship/AN-EN-Tags/master/json/tl-type.json",
                              "types data")

    operators_per_tag = {}
    for operator_json in operators_json:
        try:
            if operator_json["hidden"]:
                continue

            if "globalHidden" in operator_json and operator_json["globalHidden"]:
                continue

            operator_data = operator_data_from_json(operator_json["level"], operator_json["name_en"])

            type_en = find_translation_aceship(operator_json["type"], types_json, "type_cn", "type_en")
            add_in_dict_list(operators_per_tag, type_en, operator_data)

            for tag in operator_json["tags"]:
                tag_en = find_translation_aceship(tag, tags_json, "tag_cn", "tag_en")
                add_in_dict_list(operators_per_tag, tag_en, operator_data)

        except (KeyError, ValueError):
            raise IOError(
                f"{operator_json} is not properly formatted (missing key or value of unexpected type)")

    return operators_per_tag


def strings_equal(main_string, synonym_string, synonyms_dict):
    prev_title_lower = main_string.lower()
    new_title_lower = synonym_string.lower()

    if new_title_lower == prev_title_lower:
        return True

    if prev_title_lower not in synonyms_dict:
        return False

    return new_title_lower in synonyms_dict[prev_title_lower]


def is_operator_in(new_op, prev_op_iterable):
    for prev_op in prev_op_iterable:
        if strings_equal(prev_op[TITLE_KEY], new_op[TITLE_KEY], OPERATORS_PSEUDONYMS):
            return True

    return False


def get_synonym_tag(prev_tag, new_tags_iterable):
    for new_tag in new_tags_iterable:
        if strings_equal(prev_tag, new_tag, TAGS_SYNONYMS):
            return new_tag

    return None


def validate_pre_existing(prev_op, new_op_per_tag):
    prev_title = prev_op[TITLE_KEY]
    prev_rarity = prev_op[RARITY_KEY]

    for new_op in new_op_per_tag:
        if strings_equal(prev_title, new_op[TITLE_KEY], OPERATORS_PSEUDONYMS):
            new_rarity = new_op[RARITY_KEY]
            if prev_rarity != new_rarity:
                logger.warning(f"Rarity of {prev_title} was changed from {prev_rarity} to {new_rarity}")
                return False

            return True

    logger.warning(f"{prev_title} is present in previous data but not in new")
    return False


def validate_tag(prev_op_per_tag, new_op_per_tag):
    ok = True
    for prev_op in prev_op_per_tag:
        ok = validate_pre_existing(prev_op, new_op_per_tag) and ok

    return ok


def list_new_in_tag(tag, prev_op_per_tag, new_op_per_tag):
    for new_op in new_op_per_tag:
        if not is_operator_in(new_op, prev_op_per_tag):
            logger.info(f"New operator in tag {tag}: {new_op[TITLE_KEY]}, rarity {new_op[RARITY_KEY]}")


def validate(prev_op_per_tags, new_op_per_tags):
    ok = True
    for prev_tag in prev_op_per_tags:
        new_tag = get_synonym_tag(prev_tag, new_op_per_tags)
        if new_tag is None:
            logger.warning(f"tag {prev_tag} missing in new data")
            ok = False
        else:
            prev_op_per_tag = prev_op_per_tags[prev_tag]
            new_op_per_tag = new_op_per_tags[new_tag]
            if not validate_tag(prev_op_per_tag, new_op_per_tag):
                logger.warning(f"tag {prev_tag} contains incoherent new data (above)")
                ok = False

            list_new_in_tag(prev_tag, prev_op_per_tag, new_op_per_tag)

    return ok


def dump(dir_path, tags_file_name, operators_file_name, op_per_tags):
    # This sort is necessary because used by other components of the project
    for tag in op_per_tags:
        op_per_tags[tag].sort(reverse=True, key=lambda op: op[RARITY_KEY])

    with open(f"{dir_path}/{tags_file_name}", "w", encoding="utf-8") as operators_per_tag_file:
        json.dump(op_per_tags, operators_per_tag_file)

    operators_list = []
    titles_set = set()
    for _, operators in op_per_tags.items():
        for operator in operators:
            cur_title = operator[TITLE_KEY]
            if cur_title not in titles_set:
                titles_set.add(cur_title)
                operators_list.append(operator)

    operators_list.sort(reverse=True, key=lambda op: op[RARITY_KEY])

    with open(f"{dir_path}/{operators_file_name}", "w", encoding="utf-8") as operators_list_file:
        json.dump(operators_list, operators_list_file)


def try_download(prev_op_per_tag, dl_fun, source_name):
    try:
        operators_per_tag = dl_fun()

        if validate(prev_op_per_tag, operators_per_tag):
            dump("../arknights recruitment", "operators_per_tag.json",
                 "operators_list.json", operators_per_tag)
        else:
            dump(".", "incoherent_operators_per_tag.json",
                 "incoherent_operators_list.json", operators_per_tag)
            raise IOError("Data not coherent with previous data, see logs")
        exit(0)
    except IOError as e:
        logger.error(f"Unable to update from {source_name}: {e}")


if __name__ == "__main__":
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)

    logging_formatter = logging.Formatter("%(levelname)s: %(name)s: %(message)s")

    file_logging_handler = logging.FileHandler("update_arknights_operators.log", "w")
    file_logging_handler.setLevel(logging.INFO)
    file_logging_handler.setFormatter(logging_formatter)
    logger.addHandler(file_logging_handler)

    stdout_logging_handler = logging.StreamHandler(sys.stdout)
    stdout_logging_handler.setLevel(logging.DEBUG)
    stdout_logging_handler.setFormatter(logging_formatter)
    logger.addHandler(stdout_logging_handler)

    with open("../arknights recruitment/operators_per_tag.json", "r", encoding="UTF-8") as prev_operators_per_tag_file:
        prev_operators_per_tag = json.load(prev_operators_per_tag_file)

        try_download(prev_operators_per_tag, try_download_gamepress, "GamePress")
        try_download(prev_operators_per_tag, try_download_aceship, "Aceship")
