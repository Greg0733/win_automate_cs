import html
import json

import requests


RARITY_TO_TAG = {2: "starter",
                 5: "senior operator",
                 6: "top operator"}


def send_request(url, expected_response_name):
    response = requests.get(url)
    if response.status_code != 200:
        print(f"request for {expected_response_name} failed")
        exit(0)

    try:
        response_json = response.json()
    except requests.exceptions.JSONDecodeError:
        print(f"{expected_response_name} is not json-formatted")
        exit(0)

    return response_json


def add_in_dict_list(data_dict, key, value):
    if key not in data_dict:
        data_dict[key] = []

    data_dict[key].append(value)


def try_download_gamepress():
    arknights_json = send_request("https://gamepress.gg/json-list?_format=json&game_tid=1026&", "arknights data")

    try:
        operators_data_url = next(filter(lambda x: "operator-data-full" in x["title"], arknights_json))["url"]
    except StopIteration | KeyError:
        print("Operator data url not found in arknights json from GamePress")
        exit(0)

    operators_json = send_request(operators_data_url, "operators data")

    operators_per_tag = {}
    for operator_json in operators_json:
        if "on" not in operator_json["in_crafting_pool"].lower():
            continue

        try:
            operator_rarity = int(operator_json["rarity"])
            operator_data = {"title": html.unescape(operator_json["title"]), "rarity": operator_rarity}
            if operator_rarity in RARITY_TO_TAG:
                add_in_dict_list(operators_per_tag, RARITY_TO_TAG[operator_rarity], operator_data)

            add_in_dict_list(operators_per_tag, operator_json["position"].lower(), operator_data)

            add_in_dict_list(operators_per_tag, operator_json["profession_plain"].lower(), operator_data)

            for tag in operator_json["tags"].split(", "):
                if not tag.startswith("tag-"):
                    print("tag element does not start with 'tag-'")
                    exit(0)

                add_in_dict_list(operators_per_tag, tag[4:].lower(), operator_data)

        except KeyError | ValueError:
            print(f"{operator_json} is not properly formatted (missing key or value of unexpected type)")
            exit(0)

    # This sort is necessary because used by other components of the project
    for tag in operators_per_tag:
        operators_per_tag[tag].sort(reverse=True, key=lambda op: op["rarity"])

    with open("../arknights recruitment/operators_per_tag.json", "w", encoding="utf-8") as operators_per_tag_file:
        json.dump(operators_per_tag, operators_per_tag_file)

    operators_list = []
    titles_set = set()
    for _, operators in operators_per_tag.items():
        for operator in operators:
            cur_title = operator["title"]
            if cur_title not in titles_set:
                titles_set.add(cur_title)
                operators_list.append(operator)

    operators_list.sort(reverse=True, key=lambda op: op["rarity"])

    with open("../arknights recruitment/operators_list.json", "w", encoding="utf-8") as operators_list_file:
        json.dump(operators_list, operators_list_file)


if __name__ == "__main__":
    try_download_gamepress()
