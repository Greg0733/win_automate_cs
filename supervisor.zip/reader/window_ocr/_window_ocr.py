import pickle
from pathlib import Path
from typing import List, Tuple, Iterable
from statistics import mean

import numpy as np
# noinspection PyPackageRequirements
import win32gui
import win32ui
import win32con

from PIL import Image, ImageDraw, ImageFont


class WindowOcr:
    DEFAULT_IMAGE_MODE = "RGB"

    def __init__(self, *load_reader_args, **reader_fun_kwargs):
        self.window_handle = None
        self.results_transform = None
        self.img_transform = None
        self.img_transformed = None
        self.read_results = None
        self.img = None
        self.image_mode = None
        self.reader_fun_kwargs = {}
        self.reader_fun = None

        self.load_reader(*load_reader_args, **reader_fun_kwargs)

    def load_reader(self, fun, img_transform=lambda x: np.array(x), results_transform=lambda x: x, **kwargs):
        self.reader_fun = fun
        self.img_transform = img_transform
        self.results_transform = results_transform
        self.update_reader_kwarg(**kwargs)

    def update_reader_kwarg(self, **kwargs):
        for k in kwargs:
            self.reader_fun_kwargs[k] = kwargs[k]

    def prepare_img(self, img, image_mode=DEFAULT_IMAGE_MODE):
        self.img = img
        self.img_transformed = self.img_transform(self.img)
        self.image_mode = image_mode

    def search_window_handle(self, window_filter):
        self.window_handle = get_window_handle(window_filter)

    def prepare_screenshot(self, crop_rect_percentage=(0, 0, 1, 1), image_mode=DEFAULT_IMAGE_MODE):
        self.prepare_img(screenshot_from_handle(self.window_handle, crop_rect_percentage, image_mode), image_mode)

    def read_text(self):
        self.read_results = self.results_transform(self.reader_fun(self.img_transformed, **self.reader_fun_kwargs))
        return self.read_results

    def draw_results(self, dump_path):
        draw_text_img_results(self.img, self.read_results, dump_path)

    def read_handle(self, crop_rect_percentage=(0, 0, 1, 1), image_mode=DEFAULT_IMAGE_MODE):
        self.prepare_screenshot(crop_rect_percentage, image_mode)
        return self.read_text()

    def draw_read_handle(self, dump_path, crop_rect_percentage=(0, 0, 1, 1), image_mode=DEFAULT_IMAGE_MODE):
        self.read_handle(crop_rect_percentage, image_mode)
        self.draw_results(dump_path)


def elem_len(it: Iterable):
    return len(next(iter(it)))


def simplify_box(box: Iterable[Tuple[float, float]]):
    return tuple(float(mean([pos[i] for pos in box])) for i in range(elem_len(box)))


def simplify_results(results):
    return [[result[1].lower(), simplify_box(result[0])] for result in results]


def draw_text_img_results(img: Image,
                          results: List[Tuple[Tuple[Tuple[float, float],
                                                    Tuple[float, float],
                                                    Tuple[float, float],
                                                    Tuple[float, float]],
                                              str,
                                              int]],
                          dump_path: Path | str,
                          *,
                          text_lines_per_image=15,
                          text_font_name="LiberationSans-Regular.ttf",
                          img_mode="RGB"):
    img.save(f"{dump_path}img.png")
    results_path = f"{dump_path}imgWithResults.png"

    if len(results) < 1:
        img.save(results_path)
        return img

    img_drawer = ImageDraw.Draw(img)

    text_line_height = img.height / text_lines_per_image
    text_lines_top_to_content = {}
    for box, text, confidence in results:
        print(f"box : {box}, text : {text}, confidence : {confidence}")

        cur_text_pos = (box[2][1] + box[0][1]) / 2
        rounded_text_pos = round(cur_text_pos // text_line_height * text_line_height)
        printed_text = f"{text}: {round(confidence * 100)}"
        if rounded_text_pos in text_lines_top_to_content:
            text_lines_top_to_content[rounded_text_pos] += f" | {printed_text}"
        else:
            text_lines_top_to_content[rounded_text_pos] = printed_text

        img_drawer.rectangle((tuple(box[0]), tuple(box[2])), outline="red", width=2)

    text_font = ImageFont.truetype(text_font_name, size=round(2 / 3 * text_line_height))
    for textLineTop in text_lines_top_to_content:
        text = text_lines_top_to_content[textLineTop]
        text_lines_top_to_content[textLineTop] = (text, img_drawer.textlength(text, font=text_font))

    # noinspection PyTypeChecker
    max_text_length = round(max([x[1] for x in text_lines_top_to_content.values()]))
    # noinspection PyTypeChecker
    img_with_results = Image.new(img_mode, (img.width + max_text_length, img.height), "white")
    img_with_results.paste(img, (max_text_length, 0))
    img_drawer = ImageDraw.Draw(img_with_results)

    for textLineTop in text_lines_top_to_content:
        text, text_length = text_lines_top_to_content[textLineTop]
        img_drawer.text((max_text_length - text_length, textLineTop), text, fill="red", font=text_font)

    img_with_results.save(results_path)
    with open(f"{dump_path}result.pickle", "wb") as resultFile:
        pickle.dump(results, resultFile)

    return img_with_results


def get_window_handle(window_filter):
    def _enum_window_callback(hwnd, windows_list):
        windows_list.append((hwnd, win32gui.GetWindowText(hwnd)))

    windows = []
    win32gui.EnumWindows(_enum_window_callback, windows)
    try:
        window_handle = next(filter(window_filter, windows))[0]
    except StopIteration:
        raise ValueError("No window match the given filter") from None

    return window_handle


def screenshot_from_handle(window_handle, crop_rect_percentage, image_mode):
    crop_left, crop_top, crop_right, crop_bottom = crop_rect_percentage
    if crop_left >= crop_right or crop_top >= crop_bottom:
        raise ValueError("Cropping rectangle should be given as left, top, right, bottom, "
                         "with right (3) > left (1) and bottom (4) > top (2)")

    rect_left, rect_top, rect_right, rect_bottom = win32gui.GetWindowRect(window_handle)
    client_left, client_top = win32gui.ClientToScreen(window_handle, (0, 0))
    bounding_rect_padding = client_left - rect_left
    title_bar_height_with_padding = client_top - rect_top
    client_width = rect_right - client_left - bounding_rect_padding
    screenshot_width = int(client_width * (crop_right - crop_left))
    client_height = rect_bottom - client_top - bounding_rect_padding
    screenshot_height = int(client_height * (crop_bottom - crop_top))

    screenshot_left = int(bounding_rect_padding + crop_left * client_width)
    screenshot_top = int(title_bar_height_with_padding + crop_top * client_height)

    window_dc = win32gui.GetWindowDC(window_handle)
    new_dc = win32ui.CreateDCFromHandle(window_dc)
    output_dc = new_dc.CreateCompatibleDC()

    output_bitmap = win32ui.CreateBitmap()
    output_bitmap.CreateCompatibleBitmap(new_dc, screenshot_width, screenshot_height)
    output_dc.SelectObject(output_bitmap)
    output_dc.BitBlt((0, 0), (screenshot_width, screenshot_height), new_dc, (screenshot_left, screenshot_top),
                     win32con.SRCCOPY)

    bitmap_bits = output_bitmap.GetBitmapBits(True)
    img = Image.frombytes(image_mode, (output_bitmap.GetInfo()['bmWidth'], output_bitmap.GetInfo()['bmHeight']),
                          bitmap_bits, 'raw', 'BGRX')

    win32gui.DeleteObject(output_bitmap.GetHandle())
    output_dc.DeleteDC()
    new_dc.DeleteDC()
    win32gui.ReleaseDC(window_handle, window_dc)

    return img
