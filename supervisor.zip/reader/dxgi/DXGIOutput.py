import ctypes

import comtypes

from reader.dxgi.cStructs.dxgiStructs import IDXGIAdapter1, IDXGIOutput, IDXGIOutputDuplication, \
    DXGI_ERROR_ACCESS_LOST
from reader.dxgi.lib_wrappers import is_error_of_type, duplicate_frame, start_duplication, release_duplicator_frame, \
    release_duplicator


class DXGIOutput:
    duplicator: ctypes.POINTER(IDXGIOutputDuplication)
    adapter: ctypes.POINTER(IDXGIAdapter1)
    output: ctypes.POINTER(IDXGIOutput)
    max_retries: int

    def __init__(self, output: ctypes.POINTER(IDXGIOutput), adapter: ctypes.POINTER(IDXGIAdapter1),
                 max_retries: int = 3):
        self.duplicator = None
        self.adapter = adapter
        self.output = output
        self.max_retries = max_retries

    def try_screenshot(self, try_count: int = 1):
        self.ensure_duplication_started()

        try:
            texture = duplicate_frame(self.duplicator)



            success = True
        except comtypes.COMError as ce:
            success = self.on_screenshot_com_error(ce, try_count)
        finally:
            release_duplicator_frame(self.duplicator)

        return success

    def on_screenshot_com_error(self, ce: comtypes.COMError, try_count: int):
        if is_error_of_type(ce, DXGI_ERROR_ACCESS_LOST):
            if try_count < self.max_retries:
                self.restart()
                return self.try_screenshot(try_count + 1)
            return False

    def restart(self):
        self.release()
        self.duplicator = start_duplication(self.output, self.adapter)

    def release(self):
        if self.duplicator is not None:
            release_duplicator(self.duplicator)
            self.duplicator = None

    def ensure_duplication_started(self):
        if self.duplicator is None:
            self.duplicator = start_duplication(self.output, self.adapter)
