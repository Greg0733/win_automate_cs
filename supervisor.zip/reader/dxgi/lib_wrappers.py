from typing import List, Tuple
import ctypes

import comtypes

from .cStructs.d3d11Structs import ID3D11Texture2D
from .cStructs.dxgiStructs import (DXGI_ERROR_NOT_FOUND, IDXGIAdapter1, IDXGIFactory1,
                                   IDXGIOutput1, DXGIOutputDesc, DXGIAdapterDesc1, DXGIOutputDuplFrameInfo,
                                   IDXGIResource, IDXGIOutputDuplication, IDXGIOutput)


class AdapterInfo:
    def __init__(self, dxgi_adapter: ctypes.POINTER(IDXGIAdapter1)):
        p_desc = get_dxgi_adapter_desc(dxgi_adapter)
        self.description = p_desc.Description
        self.vendor_id = p_desc.VendorId
        self.device_id = p_desc.DeviceId
        self.sub_sys_id = p_desc.SubSysId
        self.revision = p_desc.Revision
        self.dedicated_video_memory = p_desc.DedicatedVideoMemory
        self.dedicated_system_memory = p_desc.DedicatedSystemMemory
        self.shared_system_memory = p_desc.SharedSystemMemory
        self.adapter_long_uid = p_desc.AdapterLuid
        self.flags = p_desc.Flags


class OutputInfo:
    def __init__(self, dxgi_output: ctypes.POINTER(IDXGIOutput1)):
        p_desc = get_dxgi_output_desc(dxgi_output)
        self.device_name = p_desc.DeviceName
        self.desktop_coordinates = p_desc.DesktopCoordinates
        self.is_attached_to_desktop = p_desc.AttachedToDesktop
        self.rotation_id = p_desc.Rotation
        self.monitor_handle = p_desc.Monitor


def get_dxgi_adapters() -> List[ctypes.POINTER(IDXGIAdapter1)]:
    create_dxgi_factory = ctypes.windll.dxgi.CreateDXGIFactory1
    create_dxgi_factory.argtypes = (comtypes.GUID, ctypes.POINTER(ctypes.c_void_p))
    create_dxgi_factory.restype = ctypes.c_int32
    dxgi_factory_pointer = ctypes.c_void_p(0)
    create_dxgi_factory(IDXGIFactory1.get_iid(), ctypes.byref(dxgi_factory_pointer))
    dxgi_factory = ctypes.POINTER(IDXGIFactory1)(dxgi_factory_pointer.value)
    i = 0
    p_adapters = list()
    while True:
        try:
            p_adapter = ctypes.POINTER(IDXGIAdapter1)()
            dxgi_factory.EnumAdapters1(i, ctypes.byref(p_adapter))
            p_adapters.append(p_adapter)
            i += 1
        except comtypes.COMError as ce:
            if ctypes.c_int32(DXGI_ERROR_NOT_FOUND).value == ce.args[0]:
                break
            else:
                raise ce
    return p_adapters


def get_dxgi_outputs_for_adapter(
        dxgi_adapter: ctypes.POINTER(IDXGIAdapter1),
) -> List[ctypes.POINTER(IDXGIOutput1)]:
    i = 0
    p_outputs = list()
    while True:
        try:
            p_output = ctypes.POINTER(IDXGIOutput1)()
            dxgi_adapter.EnumOutputs(i, ctypes.byref(p_output))
            p_outputs.append(p_output)
            i += 1
        except comtypes.COMError as ce:
            if is_error_of_type(ce, DXGI_ERROR_NOT_FOUND):
                break
            else:
                raise ce
    return p_outputs


def get_dxgi_adapters_and_outputs() -> Tuple[List[ctypes.POINTER(IDXGIAdapter1)], List[ctypes.POINTER(IDXGIOutput1)]]:
    adapters = get_dxgi_adapters()
    outputs = []
    for adapter in adapters:
        outputs += get_dxgi_outputs_for_adapter(adapter)

    return adapters, outputs


def get_dxgi_adapter_desc(dxgi_adapter: ctypes.POINTER(IDXGIAdapter1)) -> DXGIAdapterDesc1:
    p_desc = DXGIAdapterDesc1()
    dxgi_adapter.GetDesc1(ctypes.byref(p_desc))
    return p_desc


def get_dxgi_output_desc(
        dxgi_output: ctypes.POINTER(IDXGIOutput1)
) -> DXGIOutputDesc:
    p_desc = DXGIOutputDesc()
    dxgi_output.GetDesc(ctypes.byref(p_desc))
    return p_desc


def is_error_of_type(com_error: comtypes.COMError, error_type: int):
    return ctypes.c_int32(error_type).value == com_error.args[0]


def start_duplication(output: ctypes.POINTER(IDXGIOutput), adapter: ctypes.POINTER(IDXGIAdapter1)):
    duplicator = ctypes.POINTER(IDXGIOutputDuplication)()
    output.DuplicateOutput(adapter, ctypes.byref(duplicator))
    return duplicator


def duplicate_frame(duplicator: ctypes.POINTER(IDXGIOutputDuplication)):
    """
    Returns the texture corresponding to the frame
    May raise a ComError
    """
    info = DXGIOutputDuplFrameInfo()
    res = ctypes.POINTER(IDXGIResource)()
    duplicator.AcquireNextFrame(
        0,
        ctypes.byref(info),
        ctypes.byref(res),
    )

    return res.QueryInterface(ID3D11Texture2D)


def release_duplicator_frame(duplicator: ctypes.POINTER(IDXGIOutputDuplication)):
    duplicator.ReleaseFrame()


def release_duplicator(duplicator: ctypes.POINTER(IDXGIOutputDuplication)):
    duplicator.Release()
