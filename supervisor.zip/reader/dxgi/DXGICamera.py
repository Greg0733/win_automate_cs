import ctypes
from typing import Tuple, List

from .cStructs.dxgiStructs import IDXGIAdapter1
from .lib_wrappers import OutputInfo, AdapterInfo, get_dxgi_adapters, get_dxgi_outputs_for_adapter


class DXGICamera:
    def __init__(self):
        adapters = get_dxgi_adapters()
        outputs = set()
        adaptersForOutput = {}
        for adapter in adapters:
            outputsOfAdapter = get_dxgi_outputs_for_adapter(adapter)
            outputs.update(outputsOfAdapter)
            for output in outputsOfAdapter:
                if output not in adaptersForOutput:
                    adaptersForOutput[output] = set()
                adaptersForOutput[output].add(adapter)

        self.adapterForOutput = {output: DXGICamera.get_best_adapter(adapters)
                                 for output, adapters in adaptersForOutput.values()}

        self.outputs_infos = [OutputInfo(output) for output in outputs]
        pass
        """self.devices, self.outputs = [], []
        for p_adapter in p_adapters:
            device = Device(p_adapter)
            p_outputs = device.enum_outputs()
            if len(p_outputs) != 0:
                self.devices.append(device)
                self.outputs.append([Output(p_output) for p_output in p_outputs])
        self.output_metadata = get_output_metadata()"""

    def screenshot_region(self, region: Tuple[int, int, int, int] = None):
        pass

    """
    Currently, the best adapter is the one with the most dedicated video memory,
    because it is the piece of data whose access is easiest
    """
    @staticmethod
    def get_best_adapter(adapters: List[ctypes.POINTER(IDXGIAdapter1)]):
        if len(adapters) <= 0:
            raise ValueError("No adapter available")

        curr_best = adapters[0]
        curr_best_value = AdapterInfo(curr_best).dedicated_video_memory
        for adapter in adapters[1:]:
            adapter_value = AdapterInfo(adapter).dedicated_video_memory
            if adapter_value > curr_best_value:
                curr_best = adapter
                curr_best_value = adapter_value

        return curr_best

    def grab(self, region: Tuple[int, int, int, int] = None):
        """if region is None:
            region = self.region
        self._validate_region(region)
        frame = self._grab(region)
        return frame"""