import easyocr
from reader import window_ocr
import re


def str_to_int(s):
    return int(re.sub("[^0-9]", "", s))


if __name__ == "__main__":
    language = "en"
    window = "itézed"
    height = 1392
    width = 2560
    top = 590/height
    bottom = 1260/height
    left = 400/width
    right = 2380/width

    easyocr_reader = easyocr.Reader([language])
    ocr = window_ocr.WindowOcr(easyocr_reader.readtext)
    ocr.search_window_handle(lambda w: window.lower() in w[1].lower())
    crop_rect = [left, top, right, bottom]

    while True:
        ocr_results = ocr.read_handle(crop_rect)
        all_simplified = window_ocr.simplify_results(ocr_results)
        simplified = [s[0] for s in all_simplified if "+" in s[0] or "%" in s[0]]

        nb_choices = int(len(simplified) / 4)
        for i in range(nb_choices):
            stats_index = 3 * i
            percent_index = i + nb_choices * 3

            logistics = str_to_int(simplified[stats_index])
            intell = str_to_int(simplified[stats_index + 1])
            medic = str_to_int(simplified[stats_index + 2])

            percent = str_to_int(simplified[percent_index])

            expectation = (logistics + intell + medic) * percent/100

            print(f"Choice {i+1} : l = {logistics}, i = {intell}, medic = {medic}, percent = {percent},"
                  f" expectation = {expectation}")

        input("Enter to continue")
